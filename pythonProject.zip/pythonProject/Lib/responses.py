import random


R_Eating="I don't like eating anything because I'm a bot obviously"
def unknown():
    response=["could you please rephrase that?",
              "....",
              "Sounds about right",
              "What does that mean?"][random.randrange(4)]
    return response